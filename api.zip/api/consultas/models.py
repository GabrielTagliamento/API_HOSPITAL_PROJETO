from django.db import models
from uuid import uuid4

# Create your models here.

class Consultas(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid4, editable=False)
    paciente = models.CharField(max_length=30)
    profissional = models.CharField(max_length=30)
    data_hora = models.DateTimeField()
    status = models.CharField(max_length=200)
    tipo = models.CharField(max_length=100)
