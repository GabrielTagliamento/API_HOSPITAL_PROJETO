from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from consultas.api import serializers
from consultas import models

class ConsultasViewSet(viewsets.ModelViewSet):
    permission_classes = (IsAuthenticated,)
    serializer_class = serializers.ConsultasSerializers
    queryset = models.Consultas.objects.all()