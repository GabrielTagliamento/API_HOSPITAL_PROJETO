from rest_framework import serializers
from consultas import models

class ConsultasSerializers(serializers.ModelSerializer):
    class Meta:
        model = models.Consultas
        fields ='__all__'