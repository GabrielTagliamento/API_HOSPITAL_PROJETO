
# 🏥 Projeto SGHSS - Sistema de Gestão Hospitalar e de Serviços de Saúde (Back-end)

Este projeto é um sistema back-end básico criado com Django e Django REST Framework, que implementa:

- Registro e login de paciente
- Autenticação JWT
- CRUD de consultas
- Banco de dados SQLite
- Testável via Postman

## ✅ Tecnologias Utilizadas

- Python 3.10+
- Django 4.x
- Django REST Framework
- Simple JWT
- SQLite3

## 🚀 Como Executar o Projeto (Passo a Passo)

crie seu ambiente virtual


python -m venv venv



venv\Scripts\activate
windows

linux/mac
source venv/bin/activate

instale as dependencias
pip install -r requirements.txt


instalação manual pip install django djangorestframework djangorestframework-simplejwt

aplique as migrações  
python manage.py makemigrations
python manage.py migrate

crie o usuario que pode acessar o sistema 
python manage.py createsuperuser

inicie o servidor local
python manage.py runserver

Rotas de Autenticação
POST /token/ → Gera o token de acesso

POST /token/refresh/ → Atualiza o token de acesso

endpoints   POST http://127.0.0.1:8000/token/
            POST http://127.0.0.1:8000/token/refresh/
            GET  http://127.0.0.1:8000/consultas/
            PUT  http://127.0.0.1:8000/consultas/ID/
            DELETE http://127.0.0.1:8000/consultas/ID/
            GET    http://127.0.0.1:8000/consultas/

